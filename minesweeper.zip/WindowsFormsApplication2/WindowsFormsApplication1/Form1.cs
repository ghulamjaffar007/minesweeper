﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {


        Random rand = new Random();
        int[,] array2da = new int[5, 5];
        int mines = 5;
        int count = 0;
        Button[,] but = new Button[5, 5];


        void initialize_button()
        {
            but[0, 0] = button1;
            but[0, 1] = button2;
            but[0, 2] = button3;
            but[0, 3] = button4;
            but[0, 4] = button5;
            but[1, 0] = button6;
            but[1, 1] = button7;
            but[1, 2] = button8;
            but[1, 3] = button9;
            but[1, 4] = button10;
            but[2, 0] = button11;
            but[2, 1] = button12;
            but[2, 2] = button13;
            but[2, 3] = button14;
            but[2, 4] = button15;
            but[3, 0] = button16;
            but[3, 1] = button17;
            but[3, 2] = button18;
            but[3, 3] = button19;
            but[3, 4] = button20;
            but[4, 0] = button21;
            but[4, 1] = button22;
            but[4, 2] = button23;
            but[4, 3] = button24;
            but[4, 4] = button25;

        }
        int calculate_neighbour(int ri, int ci)
        {
            int count = 0;
            for (int i = ri - 1; i <= ri + 1; i++)
            {
                for (int j = ci - 1; j <= ci + 1; j++)
                {
                    if (i == -1 || j == -1 || i == 5 || j == 5)
                        continue;
                    if (i == ri && j == ci)
                        continue;
                    if (array2da[i, j] == -1)
                        count++;
                }
            }
            return count;
        }
        void init_array()
        {

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    array2da[i, j] = 0;
                }
            }


            int c = 0;
            while (c < mines)
            {
                int ri = rand.Next(0, 5);
                int ci = rand.Next(0, 5);
                if (array2da[ri, ci] == 0)
                {
                    array2da[ri, ci] = -1;
                    c++;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (array2da[i, j] != -1)
                        array2da[i, j] = calculate_neighbour(i, j);

                }

            }

            initialize_button();
        }

        public Form1()
        {
            InitializeComponent();
            init_array();
            
        }
      

        void open_zeros(int main_ri,int main_ci)
        {
        	if (main_ri == -1 || main_ci == -1 || main_ri== 5 || main_ci == 5)
		        return;
        	if (array2da[main_ri,main_ci] == -1)
		        return;
	        if (array2da[main_ri,main_ci] != 0)
	         	return;
	
	        if (but[main_ri,main_ci].Text!="")
	        	return;
        	else
	        {
                string mystrng = array2da[main_ri, main_ci].ToString();
                but[main_ri, main_ci].Text = mystrng;
                but[main_ri, main_ci].BackColor = Color.Green;
	        	count++;
	        }
        	open_zeros(main_ri - 1, main_ci - 1);
	        open_zeros(main_ri - 1, main_ci);
	        open_zeros( main_ri - 1, main_ci + 1);
	        open_zeros( main_ri, main_ci - 1);
	        open_zeros( main_ri, main_ci + 1);
	        open_zeros(main_ri + 1, main_ci - 1);
	        open_zeros(main_ri + 1, main_ci);
	        open_zeros(main_ri + 1, main_ci + 1);


    }
        void perfome(int i, int j)
        {
            if (textBox1.Text == "")
            {
                if (count == 25 - mines)
                    textBox1.Text = " you win :) ";
                if (array2da[i, j] == -1)
                {

                    but[i, j].Text = "*";
                    for (int m = 0; m < 5;m++ )
                    {
                        for(int k=0;k<5;k++)
                        {
                            if(array2da[m,k]==-1)
                                but[m, k].Text = "*";
                        }
                    }
                        textBox1.Text = " You lose ";
                }
                if (array2da[i, j] != -1 && array2da[i, j] != 0 && but[i, j].Text == "")
                {
                    string mystrng = array2da[i, j].ToString();
                    but[i, j].Text = mystrng;
                }
                if(array2da[i, j] == 0)
                {
                    open_zeros(i, j);
                }
            }
        }
        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            perfome(0, 0);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            perfome(0, 1);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            perfome(0, 2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            perfome(0, 3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            perfome(0, 4);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            perfome(1, 0);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            perfome(1, 1);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            perfome(1, 2);
        }
        private void button9_Click(object sender, EventArgs e)
        {
            perfome(1, 3);
        }
        private void button10_Click(object sender, EventArgs e)
        {
            perfome(1, 4);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            perfome(2, 0);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            perfome(2, 1);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            perfome(2, 2);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            perfome(2, 3);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            perfome(2, 4);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            perfome(3, 0);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            perfome(3, 1);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            perfome(3, 2);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            perfome(3, 3);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            perfome(3, 4);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            perfome(4, 0);
        }

        private void button22_Click(object sender, EventArgs e)
        {

            perfome(4, 1);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            perfome(4, 2);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            perfome(4, 3);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            perfome(4, 4);

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
